import os
from re import T
import time
import numpy as np
import winsound
import requests
import sys
from IPython.display import clear_output
import pandas as pd
import datetime
import plotly.graph_objects as go
import openpyxl 
from plotly.subplots import make_subplots
import streamlit as st
import warnings
import shutil
warnings.filterwarnings('ignore')
# from openpyxl  import load_workbook
var_index = 0


st.set_page_config(layout="wide")
st.sidebar.title("Input Parameters")
lower_val = st.sidebar.number_input("Lower Value", min_value=20000, max_value=27000, value=24100, step=50)
max_val = st.sidebar.number_input("Max Value", min_value=1000, max_value=5000, value=3500, step=50)
url = 'https://www.nseindia.com/api/option-chain-indices?symbol=NIFTY'
headers = {'user-agent':
               'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ',
           'accept-encoding': 'gzip, deflate, br', 'accept-language': 'UTF-8;en-GB,en;q=0.9,en-US;q=0.8'}
session = requests.Session()
request = session.get(url, headers=headers)
cookies = dict(request.cookies)
date_placeholder = st.empty()
chart_placeholders = [st.empty() for _ in range(11)]

pd.set_option('display.max_columns', 20)
pd.set_option('display.max_rows', 200)
pd.set_option('display.width', 20000)
# lower_val = 51200
higher_val = lower_val 
lower_range = lower_val - 700
higher_range = lower_val + 700
max_val = 3500
dt = datetime.datetime.now().date()
excel_name = 'nifty_option_{}_{}.xlsx'.format(dt.day,dt.month)


def check_and_copy_file(excel_name, source_file='data.xlsx'):
    if not os.path.isfile(excel_name):
        shutil.copy2(source_file, excel_name)

def calc_new_column(df):
    return (df['CallChg'] > 0) & (df['PutChg'] < 0) | (df['CallChg'] < 0) & (df['PutChg'] > 0)


def main_function(index, excel_name):
    
    df = pd.read_excel(excel_name)
    df = df[['Time', 'CallstrikePrice', 'CallimpliedVolatility', 'PutimpliedVolatility', 
             'CalllastPrice', 'PutlastPrice', 'CallopenInterest', 'PutopenInterest']]
    
    index_values = [index - 50, index, index + 50]
    df = df[df.CallstrikePrice.isin(index_values)]
    
    df['CallChg'] = df['CallimpliedVolatility'].diff()
    df['PutChg'] = df['PutimpliedVolatility'].diff()
    df['Signal'] = calc_new_column(df)
    df['Callprichg'] = df['CalllastPrice'].diff()
    df['PutpriChg'] = df['PutlastPrice'].diff()
    df['vichange'] = df['CallChg'] - df['PutChg']
    
    df = df.tail(10)
    
    df_plot = df[['Time', 'CallstrikePrice', 'CallimpliedVolatility', 'PutimpliedVolatility', 
                  'CalllastPrice', 'PutlastPrice', 'CallopenInterest', 'PutopenInterest']].copy()
    
    df_plot['call_diff'] = df_plot['CallimpliedVolatility'].diff(periods=1)
    df_plot['put_diff'] = df_plot['PutimpliedVolatility'].diff(periods=1)
    df_plot['call_diff_1'] = df_plot['call_diff'].diff(periods=1)
    df_plot['put_diff_1'] = df_plot['put_diff'].diff(periods=1)
    df_plot['call_diff_2'] = df_plot['call_diff_1'].diff(periods=1)
    df_plot['put_diff_2'] = df_plot['put_diff_1'].diff(periods=1)
    df_plot['Call_buy'] = (df_plot['call_diff'] < 0) & (df_plot['put_diff'] > 0)
    df_plot['Put_buy'] = (df_plot['call_diff'] > 0) & (df_plot['put_diff'] < 0)
    
    return df_plot, index_values

def beep(duration, frequency, times=1):
    for _ in range(times):
        winsound.Beep(frequency, duration)

def funct_alert(flag):
    duration = 1
    frequency = 7040
    beep(duration, frequency, 3)

    if flag:
        dt = datetime.datetime.now().date()
        file_name = f'signal_{dt.day}_{dt.month}.txt'
        with open(file_name, 'a') as file:
            file.write(datetime.datetime.now().strftime("%H:%M:%S") + '\n')

def funct_refrsh():
    duration = 1
    frequency = 1540
    beep(duration, frequency)

def convert_number(num):
    if num % 100 == 0:
        return num
    return ((num + 49) // 50) * 50

def dataframe(flag1):
    global excel_name, var_index
    col_name = ["strikePrice", "openInterest", "changeinOpenInterest", "pchangeinOpenInterest", 
                "totalTradedVolume", "impliedVolatility", "lastPrice", "change", "pChange", 
                "totalBuyQuantity", "totalSellQuantity", "bidQty", "bidprice", "askQty", "askPrice", "underlyingValue"]

    current_time = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"Current Time = {current_time}")

    while True:
        try:
            response = session.get(url, headers=headers, cookies=cookies, timeout=200).json()
            rawdata = pd.DataFrame(response)
            rawop = pd.DataFrame(rawdata['filtered']['data']).fillna(0)
            break
        except Exception as e:
            print(e)
            time.sleep(3)
            print("Sleeping...")
            continue

    excel_date = datetime.datetime.now().strftime("%Y-%m-%d")
    excel_time = datetime.datetime.now().strftime("%H:%M:%S")
    excel_flag = True
    data = []

    for i in range(len(rawop)):
        date1 = datetime.datetime.now()
        calloi = callcoi = cltp = putoi = putcoi = pltp = 0
        stp = rawop['strikePrice'][i]

        if rawop['CE'][i]:
            calloi = rawop['CE'][i]['openInterest']
            callcoi = rawop['CE'][i]['changeinOpenInterest']
            cltp = rawop['CE'][i]['lastPrice']
            index = rawop['CE'][i]['underlyingValue']
        
        if rawop['PE'][i]:
            putoi = rawop['PE'][i]['openInterest']
            putcoi = rawop['PE'][i]['changeinOpenInterest']
            pltp = rawop['PE'][i]['lastPrice']

        opdata = {
            'Date_stamp': date1, 'CALL OI': calloi, 'CALL CHNG OI': callcoi, 'CALL LTP': cltp, 
            'STRIKE PRICE': int(stp), 'PUT LTP': pltp, 'PUT CHNG OI': putcoi, 'PUT OI': putoi
        }
        data.append(opdata)
        var_index = index

        excel_op = {'Date': excel_date, 'Time': excel_time}
        for col in col_name:
            excel_op[f'Call{col}'] = rawop['CE'][i].get(col, 0)
            excel_op[f'Put{col}'] = rawop['PE'][i].get(col, 0)

        if excel_flag:
            df_excel = pd.DataFrame(excel_op, index=['CallstrikePrice'])
        else:
            df_excel = df_excel._append(excel_op, ignore_index=True)
        
        excel_flag = False

    if flag1:
        if os.path.isfile(excel_name):
            book = pd.read_excel(excel_name)
            updated_book = book._append(df_excel, ignore_index=True)
            updated_book.to_excel(excel_name, index=False)
        else:
            shutil.copy2('data.xlsx', excel_name)

    if flag1:
        time.sleep(10)

    optionchain = pd.DataFrame(data)
    return optionchain, var_index

def main_funct():
    global var_index
    flag1 = True
    counter = 0
    hit_counter = 0
    var_div = 5
    strp = 0
    loop_flag = True
    previous_df = None
    
    while loop_flag:
        clear_output(wait=True)
        counter += 1
        print(counter)
        df_plot = pd.DataFrame()
        
        if counter == 1:
            current_time = datetime.datetime.now().strftime("%H:%M:%S")
            Refresh0 = current_time
            Refresh1 = current_time
            Refresh2 = current_time
            Refresh3 = current_time
            Refresh4 = current_time

            df1, var_index = dataframe(flag1)
            strp = convert_number(var_index)

            df1.drop(['Date_stamp', 'CALL CHNG OI', 'CALL LTP', 'PUT LTP', 'PUT CHNG OI'], axis=1, inplace=True)
            df1 = df1.set_index('STRIKE PRICE')
            df_final_check = df1.loc[lower_val:higher_val]

            df_concat = pd.concat([df1.add_suffix(f'_{i+1}') for i in range(6)], axis=1)

            df_show = df_concat.reset_index()
            df_show = df_show[(df_show['STRIKE PRICE'] > lower_range) & (df_show['STRIKE PRICE'] < higher_range)].dropna()
            
        else:
            str_t = datetime.datetime.now().strftime('%Y:%m:%d__%H:%M:%S').replace(":", "_")
            str_c = datetime.datetime.now().strftime('%Y:%m:%d__%H:%M:%S').replace(":", "_")
            arr = np.array(df_cal.index)
            animals = list(map(str, arr))

            x = animals
            trace1 = go.Bar(x=x, y=df_total['Put 0Min'], name='trace1', marker_color='rgb(0, 102, 19)')
            trace2 = go.Bar(x=x, y=df_cal['Put 0Min'], name='trace2', marker_color='rgb(66, 245, 123)')
            trace3 = go.Bar(x=x, y=df_cal['Call 0Min'], name='trace3', marker_color='rgb(247, 156, 156)')
            trace4 = go.Bar(x=x, y=df_total['Call 0Min'], name='trace4', marker_color='rgb(237, 5, 5)')

            fig = go.Figure(data=[trace1, trace2, trace3, trace4])
            fig.update_layout(barmode='group', width=1000, height=350)
            chart_placeholders[0].plotly_chart(fig)

            df_plot_main, index_values = main_function(lower_val)
            df_plot = df_plot_main[df_plot_main.CallstrikePrice == index_values[1]]
            date_placeholder.write(df_plot['Time'].max())

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['CallimpliedVolatility'], name='CallIV', line=dict(color='green', width=2)))
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['PutimpliedVolatility'], name='PutIV', line=dict(color='red', width=2)))
            fig.update_layout(xaxis_tickangle=-45, width=1000, height=350)
            chart_placeholders[1].plotly_chart(fig)

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['CallopenInterest'], name='CallopenInterest', line=dict(color='green', width=2)))
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['PutopenInterest'], name='PutopenInterest', line=dict(color='red', width=2)))
            fig.update_layout(xaxis_tickangle=-45, width=1000, height=350, yaxis_title=index_values[1])
            chart_placeholders[6].plotly_chart(fig)

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['CallopenInterest'], name='CallopenInterest', line=dict(color='green', width=2)))
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['PutopenInterest'], name='PutopenInterest', line=dict(color='red', width=2)))
            fig.update_layout(xaxis_tickangle=-45, width=1000, height=350, yaxis_title=index_values[0])
            chart_placeholders[8].plotly_chart(fig)

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['CallopenInterest'], name='CallopenInterest', line=dict(color='green', width=2)))
            fig.add_trace(go.Scatter(x=df_plot['Time'], y=df_plot['PutopenInterest'], name='PutopenInterest', line=dict(color='red', width=2)))
            fig.update_layout(xaxis_tickangle=-45, width=1000, height=350, yaxis_title=index_values[2])
            chart_placeholders[10].plotly_chart(fig)

            print("Refresh Time =", Refresh)
            print("Refresh Time1 =", Refresh1)
            print("Refresh Time2 =", Refresh2)
            print("Refresh Time3 =", Refresh3)
            print("Refresh Time4 =", Refresh4)

            df, var_index = dataframe(flag1)
            strp = convert_number(var_index)
            df.drop(['Date_stamp', 'CALL CHNG OI', 'CALL LTP', 'PUT LTP', 'PUT CHNG OI'], axis=1, inplace=True)
            df = df.set_index('STRIKE PRICE')
            df_validate = df.loc[lower_val:higher_val]

            if df_validate.iloc[0][0] == df_final_check.iloc[0][0]:
                print('***' * 30)
                print(df_final_check)
                print(df_validate)
                flag1 = False
                time.sleep(10)
                continue
            else:
                print(df_validate)
                print(df_final_check)
                flag1 = True
                funct_refrsh()
                hit_counter += 1

            df_concat = pd.concat([df1.add_suffix(f'_{i+1}') for i in range(6)], axis=1)

        df_show = df_concat.reset_index()
        df_show = df_show[(df_show['STRIKE PRICE'] > lower_range) & (df_show['STRIKE PRICE'] < higher_range)].dropna()
        df_cal = pd.DataFrame(df_show['STRIKE PRICE'])
        df_cal['Put 8Min'] = df_show['PUT OI5'] - df_show['PUT OI6']
        df_cal['Put 6Min'] = df_show['PUT OI4'] - df_show['PUT OI5']
        df_cal['Put 4Min'] = df_show['PUT OI3'] - df_show['PUT OI4']
        df_cal['Put 2Min'] = df_show['PUT OI2'] - df_show['PUT OI3']
        df_cal['Put 0Min'] = df_show['PUT OI'] - df_show['PUT OI2']
        df_cal['Call 0Min'] = df_show['CALL OI'] - df_show['CALL OI2']
        df_cal['Call 2Min'] = df_show['CALL OI2'] - df_show['CALL OI3']
        df_cal['Call 4Min'] = df_show['CALL OI3'] - df_show['CALL OI4']
        df_cal['Call 6Min'] = df_show['CALL OI4'] - df_show['CALL OI5']
        df_cal['Call 8Min'] = df_show['CALL OI5'] - df_show['CALL OI6']

        df_cal = df_cal.set_index('STRIKE PRICE')
        df_total = df_cal[['Put 0Min', 'Call 0Min']]

        if hit_counter <= 5:
            var_div = hit_counter
        else:
            var_div = 5

        df_total['Put 0Min'] = df_cal['Put 8Min'] + df_cal['Put 6Min'] + df_cal['Put 4Min'] + df_cal['Put 2Min'] + df_cal['Put 0Min']
        df_total['Call 0Min'] = df_cal['Call 0Min'] + df_cal['Call 2Min'] + df_cal['Call 4Min'] + df_cal['Call 6Min'] + df_cal['Call 8Min']
        df_total['Put 0Min'] /= var_div
        df_total['Call 0Min'] /= var_div

        Refresh = datetime.datetime.now().strftime("%H:%M:%S")
        Refresh4 = Refresh3
        Refresh3 = Refresh2
        Refresh2 = Refresh1
        Refresh1 = Refresh0
        Refresh0 = Refresh

        print('*' * 50, flag1)
        if flag1:
            print(df_cal['Put 0Min'])
            print(df_total['Put 0Min'])

            for i, j in zip(df_cal['Put 0Min'], df_cal['Call 0Min']):
                if (i > max_val) or (i < -(max_val)):
                    chart_placeholders[3].dataframe(df_plot[(df_plot['Put 0Min'] == i) & (df_plot['Call 0Min'] == j)])
                    break

        if counter == var_index:
            print("Loop ended", str(var_index))
            loop_flag = False
            break        


def safe_main_funct():
    try:
        main_funct()
    except Exception as e:
        print(f"An error occurred: {e}")
        st.error(f"An error occurred: {e}")
        time.sleep(10)
        st.rerun()

if __name__ == "__main__":
    print(sys.argv)
    print(['streamlit run'] + sys.argv)

    safe_main_funct()