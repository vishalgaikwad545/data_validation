import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import datetime
import os
from glob import glob
import time
import warnings
import threading

# Suppress unnecessary warnings to keep the console clean
warnings.filterwarnings("ignore")

# Configure Streamlit page layout for better visualization
st.set_page_config(layout="wide")

class ExcelFileMonitor:
    """
    A class to monitor an Excel file for modifications in the background.
    
    This class uses a separate thread to periodically check if the file 
    has been modified, which allows for non-blocking file monitoring.
    """
    def __init__(self, file_path):
        self.file_path = file_path  # Path to the Excel file
        self.last_modified_time = None  # Track last modification time
        self.stop_monitoring = False  # Flag to stop monitoring
        self.monitoring_thread = None  # Thread for monitoring
        self.file_updated = False  # Flag to indicate file update

    def start_monitoring(self):
        """Start the background file monitoring thread."""
        self.stop_monitoring = False
        self.monitoring_thread = threading.Thread(target=self._monitor_file)
        self.monitoring_thread.daemon = True  # Allow thread to exit with main program
        self.monitoring_thread.start()

    def stop_monitoring(self):
        """Stop the monitoring thread."""
        self.stop_monitoring = True
        if self.monitoring_thread:
            self.monitoring_thread.join()

    def _monitor_file(self):
        """
        Background method to continuously check file modification time.
        Runs every 10 seconds to check for updates.
        """
        while not self.stop_monitoring:
            try:
                current_modified_time = os.path.getmtime(self.file_path)
                
                # Initialize last modified time on first run
                if self.last_modified_time is None:
                    self.last_modified_time = current_modified_time
                
                # Check if file has been modified
                if current_modified_time != self.last_modified_time:
                    self.file_updated = True
                    self.last_modified_time = current_modified_time
                    print(f"File updated: {self.file_path} {datetime.date.today()}")
            except Exception as e:
                print(f"Error monitoring file: {e}")
            
            # Wait for 10 seconds before next check
            time.sleep(10)

# Cached function to load Excel with retry mechanism
@st.cache_data(ttl=10)  # Cache for 10 seconds to allow quick reloads
def load_excel(file_path, retries=3, delay=5):
    """
    Load Excel file with multiple retry attempts.
    
    Args:
        file_path (str): Path to the Excel file
        retries (int): Number of retry attempts
        delay (int): Delay between retry attempts
    
    Returns:
        pandas.DataFrame: Loaded Excel data
    """
    for attempt in range(retries):
        try:
            return pd.read_excel(file_path, engine='openpyxl')
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                print(f"Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print("Max retries reached. Unable to load the file.")
                raise

# Function to get list of Excel files
def get_file_list(file_path):
    """
    Find all Nifty option Excel files in the specified directory.
    
    Args:
        file_path (str): Directory to search for Excel files
    
    Returns:
        list: Sorted list of Excel file paths
    """
    return glob(f"{file_path}nifty_option_*.xlsx")

# Main Streamlit application
def main():
    # Sidebar date input
    selected_date = st.sidebar.date_input("Select Date", datetime.date.today())

    # Initialize file path and monitoring
    file_path = "C:\\Users\\vbgai\\Downloads\\"
    file_pattern = f"{file_path}nifty_option_{selected_date.day}_{selected_date.month}.xlsx"
    
    # Find most recent file if specific date pattern doesn't exist
    file_list = get_file_list(file_path)
    file_list.sort(reverse=True, key=os.path.getmtime)
    
    if not os.path.exists(file_pattern) and file_list:
        file_path = file_list[0]
    else:
        file_path = file_pattern

    # Initialize file monitor in session state
    if 'file_monitor' not in st.session_state:
        st.session_state.file_monitor = ExcelFileMonitor(file_path)
        st.session_state.file_monitor.start_monitoring()

    # Check and reload if file has been updated
    if st.session_state.file_monitor.file_updated:
        st.cache_data.clear()
        st.session_state.file_monitor.file_updated = False
        st.rerun()

    # Load Excel file
    try:
        df = load_excel(st.session_state.file_monitor.file_path)
    except Exception as e:
        st.error(f"Error loading file: {e}")
        st.stop()

    # Data preprocessing
    df_backup = df.copy()
    unique_values = df_backup['PutstrikePrice'].nunique()
    value_range = st.sidebar.number_input("Enter the number of values to display", value=60, step=10)
    df = df_backup.tail(value_range * unique_values)

    # Perform data transformations (same as original script)
    df['PuttotalBuyQuantity_diff'] = df.groupby(['Time', 'PutstrikePrice'])['PuttotalBuyQuantity'].diff()
    df['CalltotalBuyQuantity_diff'] = df.groupby(['Time', 'CallstrikePrice'])['CalltotalBuyQuantity'].diff()
    df['Callprice'] = df['CallaskQty'] * df['CallaskPrice']
    df['Putprice'] = df['PutaskQty'] * df['PutaskPrice']
    df['Change_put_call'] = df['PutpchangeinOpenInterest'] - df['CallpchangeinOpenInterest']
    df['actual_change'] = df['PutopenInterest'] - df['CallopenInterest']
    df['call_quantity_change'] = df['CalltotalSellQuantity'] - df['CalltotalBuyQuantity'] 
    df['put_quantity_change'] = df['PuttotalSellQuantity'] - df['PuttotalBuyQuantity']
    df['put_call_ratio'] =  df['PutopenInterest'] / df['CallopenInterest']
    df['t_put_call_ratio'] =  df['PutchangeinOpenInterest'] / df['CallchangeinOpenInterest']
    window=3
    df['put_quantity_change_avg_increase'] = df['put_quantity_change'].rolling(window=window).apply(lambda x: round((x.iloc[-1] - x.iloc[0]) / window))
    df['call_quantity_change_avg_increase'] = df['call_quantity_change'].rolling(window=window).apply(lambda x: round((x.iloc[-1] - x.iloc[0]) / window))
    df['qty_avg_change_zero_line'] = df['call_quantity_change_avg_increase'] - df['put_quantity_change_avg_increase']

    # Sidebar inputs and options (same as original script)
    callstrike_input = st.sidebar.number_input("Enter Call Strike Price", value=23600, step=50)
    filtered_df = df[df['CallstrikePrice'] == callstrike_input]

    # Options dictionary and plot configuration (same as original script)
    options = {
        'Quantity_change':['put_quantity_change','call_quantity_change'],
        'Change in Open Interest': ['PutchangeinOpenInterest', 'CallchangeinOpenInterest'],
        'Open Interest': ['PutopenInterest', 'CallopenInterest'],
        'Total Buy Quantity': ['CalltotalBuyQuantity', 'PuttotalBuyQuantity'],
        'Total Sell Quantity': ['PuttotalSellQuantity', 'CalltotalSellQuantity'],
        'Last Price': ['CalllastPrice', 'PutlastPrice'],
        'Implied Volatility': ['CallimpliedVolatility', 'PutimpliedVolatility'],
        'Ask Quantity': ['CallaskQty', 'PutaskQty'],
        'Put Call Ratio':['put_call_ratio','put_call_ratio'],
        'Net Buy Quantity': ['CalltotalBuyQuantity_diff','PuttotalBuyQuantity_diff'],
        'Today Put Call Ratio':['t_put_call_ratio','t_put_call_ratio'],
        'Percentage Change in Open Interest': ['CallpchangeinOpenInterest', 'PutpchangeinOpenInterest'],
        'Percent_change':['Change_put_call','Change_put_call'],
        'actual_change':['actual_change','actual_change'],
        'Total Traded Volume': ['CalltotalTradedVolume', 'PuttotalTradedVolume'],


        'Change': ['Callchange', 'Putchange'],
        'Percentage Change': ['CallpChange', 'PutpChange'],

        'Bid Quantity': ['CallbidQty', 'PutbidQty'],
        'Bid Price': ['Callbidprice', 'Putbidprice'],

        'Ask Price': ['CallaskPrice', 'PutaskPrice'],
        'Underlying Value': ['CallunderlyingValue', 'PutunderlyingValue'],
        "Underlying Total Value":["Callprice","Putprice"],
        'avg_quantity_change':['put_quantity_change_avg_increase','call_quantity_change_avg_increase'],
        'qty_avg_change_zero_line':['qty_avg_change_zero_line','qty_avg_change_zero_line']
    }


    # Plot configuration
    plot_options = [
        ("Select Option to Plot", 0),
        ("Select Second Option to Plot", 1),
        ("Select Third Option to Plot", 4),
        ("Select fourth Option to Plot", 5),
        ("Select Fifth Option to Plot", 6)
    ]

    selected_options = [
        st.sidebar.selectbox(label, list(options.keys()), index=index)
        for label, index in plot_options
    ]

    if filtered_df.empty:
        st.write("No data available for the selected CallstrikePrice.")
    else:
        # Plotting function (same as original script)
        def create_figure(filtered_df, x_column, y_call_column, y_put_column, option_title, strike_price):
            fig = go.Figure()

            # Add traces for selected Call and Put columns
            fig.add_trace(go.Scatter(
                x=filtered_df[x_column], y=filtered_df[y_call_column],
                mode='lines', name=f'{y_call_column}'[:10], line=dict(color='green')
                # mode='lines', line=dict(color='green')
            ))
            fig.add_trace(go.Scatter(
                x=filtered_df[x_column], y=filtered_df[y_put_column],
                mode='lines', name=f'{y_put_column}'[:10], line=dict(color='red')
                # mode='lines',  line=dict(color='red')
            ))

            # Update layout
            fig.update_layout(
                xaxis={
                    'title': 'Time',
                    'rangeslider': {'visible': True},
                    'type': 'category',
                    'tickangle': -45,
                },
                yaxis={
                    'title': f'{option_title} for Call and Put',
                    'fixedrange': False,
                },
                title=f'{option_title} for Strike Price {strike_price}',
                height=400,
            )

            # Set dynamic y-axis scaling
            fig.update_yaxes(autorange=True)

            return fig


        # Create and display plots
        for option in selected_options:
            call_column, put_column = options[option]
            fig = create_figure(
                filtered_df, 'Time', call_column, put_column,
                option, callstrike_input
            )
            st.plotly_chart(fig, use_container_width=True)

        st.write(f"Loaded file: {os.path.basename(st.session_state.file_monitor.file_path)}")

# Run the main application
if __name__ == "__main__":
    main()