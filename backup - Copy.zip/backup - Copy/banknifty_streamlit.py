import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
import time
import datetime

# Function to load and process the data
def load_data():
    dt = datetime.datetime.now().date()
    file_path = f'bank_option_{dt.day}_{dt.month}.xlsx'
    # file_path = "bank_option_9_9.xlsx"  # Path to your file
    df = pd.read_excel(file_path)

    # Convert 'Date' and 'Time' columns to a single datetime column
    df['DateTime'] = pd.to_datetime(df['Date'].astype(str) + ' ' + df['Time'].astype(str))

    return df

# Function to plot the volume data
def plot_volume(df, strike_min, strike_max):
    # Filter the data based on the selected strike price range
    df_filtered_range = df[(df['CallstrikePrice'] >= strike_min) & (df['CallstrikePrice'] <= strike_max)]
    
    # Get unique strike prices within the range
    unique_strike_prices = df_filtered_range['CallstrikePrice'].unique()

    # Initialize plot
    fig, ax = plt.subplots(figsize=(10, 6))

    # Loop through each unique strike price in the selected range and plot the line chart
    for strike_price in unique_strike_prices:
        # Filter the data for the specific strike price
        df_filtered = df_filtered_range[df_filtered_range['CallstrikePrice'] == strike_price]

        # Plot Call volume and Put volume for each strike price
        ax.plot(df_filtered['DateTime'], df_filtered['CalltotalTradedVolume'], label=f'Call Volume - {strike_price}', linestyle='--')
        ax.plot(df_filtered['DateTime'], df_filtered['PuttotalTradedVolume'], label=f'Put Volume - {strike_price}')

    # Set labels and title
    ax.set_xlabel('Time')
    ax.set_ylabel('Volume')
    ax.set_title('Volume for Strike Prices in Selected Range Over Time')

    # Show the legend
    ax.legend(loc='upper right')

    # Return the plot figure
    return fig

# Streamlit app
st.title("Options Chain Analysis - Volume Chart")
st.write("The data refreshes every 5 seconds.")

# Sidebar to input minimum and maximum strike price values
strike_min = st.sidebar.number_input('Enter Minimum Strike Price', min_value=50000, max_value=55000, value=52000, step=100)
strike_max = st.sidebar.number_input('Enter Maximum Strike Price', min_value=50000, max_value=55000, value=53000, step=100)

# Ensure minimum is less than maximum
if strike_min >= strike_max:
    st.sidebar.error("The minimum strike price must be less than the maximum strike price.")

# Load and process data every 5 seconds
placeholder = st.empty()  # For displaying the chart

while strike_min < strike_max:  # Ensure valid range
    # Load the data
    df = load_data()

    # Plot the data based on the selected range
    with placeholder.container():
        fig = plot_volume(df, strike_min, strike_max)
        st.pyplot(fig)

    # Refresh every 5 seconds
    time.sleep(5)
