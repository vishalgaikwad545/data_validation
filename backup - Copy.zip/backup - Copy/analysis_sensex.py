import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import datetime
import time
import os
from glob import glob

# Set up page  layout
st.set_page_config(layout="wide")

# Function to load the Excel file (with caching)
@st.cache_data
def load_excel(file_path):
    return pd.read_excel(file_path)

# Function to get the list of available Excel files (with caching)
file_path = "C:\\Users\\vbgai\\Downloads\\"
# file_path = "C:\\Users\\vbgai\\OneDrive\\Desktop\\"
@st.cache_data
def get_file_list():
    # return glob("C:\\Users\\vbgai\\Downloads\\bank_option_*.xlsx")
    return glob(f"{{}}sensex_option_*.xlsx".format(file_path))
# Sidebar date input
selected_date = st.sidebar.date_input("Select Date", datetime.date.today())

# Reload button on the sidebar

if st.sidebar.button("Reload Excel"):
    # Clear the cache for both functions
    st.cache_data.clear()
    
def load_data():
    time.sleep(5)
    st.cache_data.clear()

# Construct the file path based on the selected date
file_pattern = f"{{}}sensex_option_*".format(file_path)
file_list = get_file_list()

# Check if file exists, otherwise get the latest one
if not os.path.exists(file_pattern):
    file_list.sort(reverse=True, key=os.path.getmtime)
    if file_list:
        file_path = file_list[0]
    else:
        st.error("No Excel files found.")
        st.stop()
else:
    file_path = file_pattern

# Load Excel file
df = load_excel(file_path)
df['Callprice'] = df ['CallaskQty'] * df['CallaskPrice']
df ['Putprice'] = df ['PutaskQty'] * df['PutaskPrice']
df['Change_put_call'] = df['CallpchangeinOpenInterest'] - df['PutpchangeinOpenInterest'] 
df['actual_change'] = df['PutopenInterest'] - df['CallopenInterest']
df['indicator_call1'] = df['CallopenInterest'] * df['CalllastPrice']
df['indicator_put1'] = df['PutopenInterest'] * df['PutlastPrice']
df['indicator2'] = df['indicator_call1'] - df['indicator_put1']
# Sidebar input for CallstrikePrice
callstrike_input = st.sidebar.number_input("Enter Call Strike Price", value=79500, step=100)

# Filter data based on the CallstrikePrice input (filtered early to optimize performance)
filtered_df = df[df['CallstrikePrice'] == callstrike_input]

# Dictionary mapping combined options for both Call and Put
options = {
    'Indicator1':['indicator_call1','indicator_put1'],
    'Indicator2':['indicator2','indicator2'],
    'Percent_change':['Change_put_call','Change_put_call'],
    'actual_change':['actual_change','actual_change'],
    'Open Interest': ['CallopenInterest', 'PutopenInterest'],
    'Change in Open Interest': ['CallchangeinOpenInterest', 'PutchangeinOpenInterest'],
    'Percentage Change in Open Interest': ['CallpchangeinOpenInterest', 'PutpchangeinOpenInterest'],
    'Total Traded Volume': ['CalltotalTradedVolume', 'PuttotalTradedVolume'],
    'Implied Volatility': ['CallimpliedVolatility', 'PutimpliedVolatility'],
    'Last Price': ['CalllastPrice', 'PutlastPrice'],
    'Change': ['Callchange', 'Putchange'],
    'Percentage Change': ['CallpChange', 'PutpChange'],
    'Total Buy Quantity': ['CalltotalBuyQuantity', 'PuttotalBuyQuantity'],
    'Total Sell Quantity': ['CalltotalSellQuantity', 'PuttotalSellQuantity'],
    'Bid Quantity': ['CallbidQty', 'PutbidQty'],
    'Bid Price': ['Callbidprice', 'Putbidprice'],
    'Ask Quantity': ['CallaskQty', 'PutaskQty'],
    'Ask Price': ['CallaskPrice', 'PutaskPrice'],
    'Underlying Value': ['CallunderlyingValue', 'PutunderlyingValue'],
    "Underlying Total Value":["Callprice","Putprice"],
}

# Sidebar multiselect for combined Call and Put options
selected_option = st.sidebar.selectbox("Select Option to Plot", list(options.keys()))

# Get the corresponding Call and Put columns
selected_call_column, selected_put_column = options[selected_option]

if filtered_df.empty:
    st.write("No data available for the selected CallstrikePrice.")
else:
    # Create figure using Plotly
    fig = go.Figure()

    # Add traces for selected Call and Put columns
    fig.add_trace(go.Scatter(x=filtered_df['Time'], y=filtered_df[selected_call_column],
                             mode='lines', name=f'Call {selected_call_column}', line=dict(color='green')))
    
    fig.add_trace(go.Scatter(x=filtered_df['Time'], y=filtered_df[selected_put_column],
                             mode='lines', name=f'Put {selected_put_column}', line=dict(color='red')))

    # Update layout to enable horizontal scrolling and dynamic y-axis scaling
    fig.update_layout(
        xaxis={
            'title': 'Time',
            'rangeslider': {'visible': True},
            'type': 'category',
            'tickangle': -45,
        },
        yaxis={
            'title': f'{selected_option} for Call and Put',
            'fixedrange': False,  # Allows y-axis to be dynamic
        },
        title=f'{selected_option} for Strike Price {callstrike_input}',
        height=600,
    )

    # Set dynamic y-axis scaling based on the visible x-axis range
    fig.update_yaxes(autorange=True)

    # Display the chart in Streamlit
    st.plotly_chart(fig, use_container_width=True)
    st.write(f"Loaded file: {os.path.basename(file_path)}")
    

# load_data()
