import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import datetime
import os
from glob import glob
import time

# Set up page layout
st.set_page_config(layout="wide")

# Function to load the Excel file (with caching)
@st.cache_data
def load_excel(file_path):
    return pd.read_excel(file_path)

# Function to get the list of available Excel files (with caching)
file_path = "C:\\Users\\vbgai\\Downloads\\"
@st.cache_data
def get_file_list():
    return glob(f"{{}}bank_option__*.xlsx".format(file_path))

# Sidebar date input
selected_date = st.sidebar.date_input("Select Date", datetime.date.today())

# Reload button on the sidebar
if st.sidebar.button("Reload Excel"):
    # Clear the cache for both functions
    st.cache_data.clear()

# Construct the file path based on the selected date
file_pattern = f"{{}}bank_option_{selected_date.day}_{selected_date.month}.xlsx".format(file_path)
file_list = get_file_list()

# Check if file exists, otherwise get the latest one
if not os.path.exists(file_pattern):
    file_list.sort(reverse=True, key=os.path.getmtime)
    if file_list:
        file_path = file_list[0]
    else:
        st.error("No Excel files found.")
        st.stop()
else:
    file_path = file_pattern

# Load Excel file
df = load_excel(file_path)
df['Callprice'] = df['CallaskQty'] * df['CallaskPrice']
df['Putprice'] = df['PutaskQty'] * df['PutaskPrice']
df['Change_put_call'] = df['PutpchangeinOpenInterest'] - df['CallpchangeinOpenInterest']
df['actual_change'] = df['PutopenInterest'] - df['CallopenInterest']

# Sidebar inputs for minimum, maximum, and fixed CallstrikePrice
min_value = st.sidebar.number_input("Enter Minimum Value", value=51000, step=100)
max_value = st.sidebar.number_input("Enter Maximum Value", value=51400, step=100)
fixed_value = st.sidebar.number_input("Enter Fixed Value", value=51600, step=100)
play_button = st.sidebar.button("Play")

# Filter data for the given range
options = {
    'Percent_change': ['Change_put_call', 'Change_put_call'],
    'actual_change': ['actual_change', 'actual_change'],
    'Open Interest': ['CallopenInterest', 'PutopenInterest'],
    'Change in Open Interest': ['CallchangeinOpenInterest', 'PutchangeinOpenInterest'],
    'Percentage Change in Open Interest': ['CallpchangeinOpenInterest', 'PutpchangeinOpenInterest'],
    'Total Traded Volume': ['CalltotalTradedVolume', 'PuttotalTradedVolume'],
    'Implied Volatility': ['CallimpliedVolatility', 'PutimpliedVolatility'],
    'Last Price': ['CalllastPrice', 'PutlastPrice'],
    'Change': ['Callchange', 'Putchange'],
    'Percentage Change': ['CallpChange', 'PutpChange'],
    'Total Buy Quantity': ['CalltotalBuyQuantity', 'PuttotalBuyQuantity'],
    'Total Sell Quantity': ['CalltotalSellQuantity', 'PuttotalSellQuantity'],
    'Bid Quantity': ['CallbidQty', 'PutbidQty'],
    'Bid Price': ['Callbidprice', 'Putbidprice'],
    'Ask Quantity': ['CallaskQty', 'PutaskQty'],
    'Ask Price': ['CallaskPrice', 'PutaskPrice'],
    'Underlying Value': ['CallunderlyingValue', 'PutunderlyingValue'],
    "Underlying Total Value": ["Callprice", "Putprice"],
}

# Sidebar multiselect for combined Call and Put options
selected_option = st.sidebar.selectbox("Select Option to Plot", list(options.keys()))

# Get the corresponding Call and Put columns
selected_call_column, selected_put_column = options[selected_option]

# Create a placeholder for the chart
chart_placeholder = st.empty()

# Iterate and update chart based on play button
if play_button:
    # Loop through the range from min_value to max_value
    for value in range(min_value, max_value + 1, 100):
        filtered_df = df[df['CallstrikePrice'] == value]

        if filtered_df.empty:
            st.write(f"No data available for the selected CallstrikePrice: {value}")
        else:
            # Create figure using Plotly
            fig = go.Figure()

            # Add traces for selected Call and Put columns
            fig.add_trace(go.Scatter(x=filtered_df['Time'], y=filtered_df[selected_call_column],
                                     mode='lines', name=f'Call {selected_call_column}', line=dict(color='green')))

            fig.add_trace(go.Scatter(x=filtered_df['Time'], y=filtered_df[selected_put_column],
                                     mode='lines', name=f'Put {selected_put_column}', line=dict(color='red')))

            # Update layout to enable horizontal scrolling and dynamic y-axis scaling
            fig.update_layout(
                xaxis={
                    'title': 'Time',
                    'rangeslider': {'visible': True},
                    'type': 'category',
                    'tickangle': -45,
                },
                yaxis={
                    'title': f'{selected_option} for Call and Put',
                    'fixedrange': False,  # Allows y-axis to be dynamic
                },
                title=f'{selected_option} for Strike Price {value}',
                height=600,
            )

            # Set dynamic y-axis scaling based on the visible x-axis range
            fig.update_yaxes(autorange=True)

            # Update the chart in the placeholder
            chart_placeholder.plotly_chart(fig, use_container_width=True)

            # Wait for 1 second before updating the chart
            time.sleep(1)

    # Show the chart for the fixed index after the iteration completes
    filtered_df_fixed = df[df['CallstrikePrice'] == fixed_value]

    if filtered_df_fixed.empty:
        st.write(f"No data available for the selected CallstrikePrice: {fixed_value}")
    else:
        # Create figure for the fixed index
        fig_fixed = go.Figure()

        # Add traces for selected Call and Put columns
        fig_fixed.add_trace(go.Scatter(x=filtered_df_fixed['Time'], y=filtered_df_fixed[selected_call_column],
                                       mode='lines', name=f'Call {selected_call_column}', line=dict(color='green')))

        fig_fixed.add_trace(go.Scatter(x=filtered_df_fixed['Time'], y=filtered_df_fixed[selected_put_column],
                                       mode='lines', name=f'Put {selected_put_column}', line=dict(color='red')))

        # Update layout to enable horizontal scrolling and dynamic y-axis scaling
        fig_fixed.update_layout(
            xaxis={
                'title': 'Time',
                'rangeslider': {'visible': True},
                'type': 'category',
                'tickangle': -45,
            },
            yaxis={
                'title': f'{selected_option} for Call and Put',
                'fixedrange': False,  # Allows y-axis to be dynamic
            },
            title=f'{selected_option} for Strike Price {fixed_value}',
            height=600,
        )

        # Set dynamic y-axis scaling based on the visible x-axis range
        fig_fixed.update_yaxes(autorange=True)

        # Display the final chart for the fixed index
        chart_placeholder.plotly_chart(fig_fixed, use_container_width=True)
