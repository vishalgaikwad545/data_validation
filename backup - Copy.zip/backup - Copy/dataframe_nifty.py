import streamlit as st
import pandas as pd
import asyncio
import functools
import nest_asyncio
import os
from datetime import datetime

nest_asyncio.apply()

st.set_page_config(page_title="Options Crossover Detector", layout="wide")

# Main title
st.title("Options Crossover Detection")

# Hardcoded file path
file_path = r"C:\Users\vbgai\Downloads\nifty_option_21_3.xlsx"

# Cache function to store dataframe
@st.cache_data
def load_data(excel_path, perform_calculations=True):
    try:
        if excel_path.endswith('.csv'):
            df = pd.read_csv(excel_path)
        else:
            df = pd.read_excel(excel_path, engine='openpyxl')
        
        if perform_calculations:
            df = calculate_derivatives(df)
        
        return df
    except Exception as e:
        st.error(f"Error loading file: {e}")
        return None

# Function to perform all calculations
def calculate_derivatives(df, window=5):
    try:
        # Basic calculations
        df['PuttotalBuyQuantity_diff'] = df.groupby(['Time', 'PutstrikePrice'])['PuttotalBuyQuantity'].diff()
        df['CalltotalBuyQuantity_diff'] = df.groupby(['Time', 'CallstrikePrice'])['CalltotalBuyQuantity'].diff()
        df['Callprice'] = df['CallaskQty'] * df['CallaskPrice']
        df['Putprice'] = df['PutaskQty'] * df['PutaskPrice']
        df['Change_put_call'] = df['PutpchangeinOpenInterest'] - df['CallpchangeinOpenInterest']
        df['actual_change'] = df['PutopenInterest'] - df['CallopenInterest']
        df['call_quantity_change'] = df['CalltotalSellQuantity'] - df['CalltotalBuyQuantity']
        df['put_quantity_change'] = df['PuttotalSellQuantity'] - df['PuttotalBuyQuantity']
        df['put_diff_quantity'] = df['put_quantity_change'] * df['PutimpliedVolatility']
        df['call_diff_quantity'] = df['call_quantity_change'] * df['CallimpliedVolatility']
        df['act_CallunderlyingValue'] = df['CallunderlyingValue'] - df['CallstrikePrice']
        df['act_PutunderlyingValue'] = df['PutunderlyingValue'] - df['PutstrikePrice']
        df['put_call_ratio'] = df['PutopenInterest'] / df['CallopenInterest']
        df['t_put_call_ratio'] = df['PutchangeinOpenInterest'] / df['CallchangeinOpenInterest']
        df['iv_sell_put'] = df['PuttotalSellQuantity'] * (1 + df['PutimpliedVolatility']/100)
        df['iv_sell_call'] = df['CalltotalSellQuantity'] * (1 + df['CallimpliedVolatility']/100)
        
        # Rolling calculations - handle potential errors
        try:
            df['put_quantity_change_avg_increase'] = df['put_quantity_change'].rolling(window=window).apply(
                lambda x: round((x.iloc[-1] - x.iloc[0]) / window) if len(x) == window else float('nan'))
            df['call_quantity_change_avg_increase'] = df['call_quantity_change'].rolling(window=window).apply(
                lambda x: round((x.iloc[-1] - x.iloc[0]) / window) if len(x) == window else float('nan'))
            df['qty_avg_change_zero_line'] = df['call_quantity_change_avg_increase'] - df['put_quantity_change_avg_increase']
        except Exception as e:
            st.warning(f"Could not calculate some rolling metrics: {e}")
        
        return df
    except Exception as e:
        st.error(f"Error in calculations: {e}")
        return df

# Function to process strike
def process_strike(df, strike_price, price_col1, price_col2, metric_name):
    filtered_df = df[df['CallstrikePrice'] == strike_price].copy()
    
    if len(filtered_df) < 2:
        return False, []
    
    if 'Date' in filtered_df.columns and 'Time' in filtered_df.columns:
        filtered_df['DateTime'] = pd.to_datetime(filtered_df['Date'] + ' ' + filtered_df['Time'])
        filtered_df.sort_values('DateTime', inplace=True)
    else:
        filtered_df.sort_values('Time', inplace=True)
    
    # All calculations are already done in the load_data function
    
    filtered_df['relationship'] = filtered_df[price_col1] > filtered_df[price_col2]
    filtered_df['prev_relationship'] = filtered_df['relationship'].shift()
    filtered_df['crossover'] = filtered_df['relationship'] != filtered_df['prev_relationship']
    
    crossover_df = filtered_df.dropna(subset=['prev_relationship'])
    crossover_df = crossover_df[crossover_df['crossover'] == True]
    
    crossover_df['turnover_type'] = "Negative Turnover"
    crossover_df.loc[(~crossover_df['prev_relationship']) & crossover_df['relationship'], 'turnover_type'] = "Positive Turnover"
    
    result = []
    if len(crossover_df) > 0:
        time_col = 'DateTime' if 'DateTime' in crossover_df.columns else 'Time'
        result = list(zip(crossover_df[time_col], crossover_df['turnover_type']))
    
    return len(result) > 0, result, metric_name

async def detect_crossover_async(df, strike_price, price_col1, price_col2, metric_name):
    loop = asyncio.get_event_loop()
    process_func = functools.partial(process_strike, df, strike_price, price_col1, price_col2, metric_name)
    return await loop.run_in_executor(None, process_func)

async def process_all_strikes_all_metrics(df, target_strikes, metric_pairs):
    all_tasks = []
    
    for target_strike in target_strikes:
        for metric_name, (col1, col2) in metric_pairs:
            task = detect_crossover_async(df, target_strike, col1, col2, metric_name)
            all_tasks.append(task)
    
    results = await asyncio.gather(*all_tasks)
    
    all_crossovers = []
    
    for i, result in enumerate(results):
        has_crossover, crossover_info, metric_name = result
        
        if has_crossover:
            # Calculate which strike price this result refers to
            strike_index = i // len(metric_pairs)
            target_strike = target_strikes[strike_index]
            
            for timestamp, turnover_type in crossover_info:
                all_crossovers.append({
                    'target_strike': target_strike,
                    'timestamp': timestamp,
                    'turnover_type': turnover_type,
                    'metric_pair': metric_name
                })
    
    if all_crossovers:
        result_df = pd.DataFrame(all_crossovers)
        # Sort by timestamp in descending order, then by strike price and turnover type
        result_df = result_df.sort_values(by=['timestamp', 'target_strike', 'metric_pair', 'turnover_type'], 
                                         ascending=[False, True, True, True])
        return result_df
    else:
        return pd.DataFrame(columns=['target_strike', 'timestamp', 'turnover_type', 'metric_pair'])

# Function to run async code in Streamlit
def run_async(coro):
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(coro)

# Sidebar file controls
st.sidebar.header("Data Controls")

# Option to reload the Excel file
if st.sidebar.button("Reload Excel Data"):
    # Clear cache to force reload
    st.cache_data.clear()
    st.success("Cache cleared! Data will be reloaded.")

# Load the data
with st.spinner("Loading data..."):
    df = load_data(file_path)

if df is not None:
    # Last modified time of the file
    last_modified = datetime.fromtimestamp(os.path.getmtime(file_path))
    st.success(f"Data loaded successfully from {file_path}")
    st.info(f"File last modified: {last_modified.strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Show data info
    st.sidebar.info(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")
    
    # Strike price range selection using direct input
    min_strike = st.sidebar.number_input("Minimum Strike Price", min_value=0, value=23200, step=50)
    max_strike = st.sidebar.number_input("Maximum Strike Price", min_value=min_strike, value=23400, step=50)
    step = 50
    
    # Calculate target strikes
    target_strikes = [i for i in range(min_strike, max_strike + 1, step)]
    
    # Define available metric pairs - now expanded with new calculations
    metric_pairs = [
        ("iv_sell_put vs iv_sell_call", ("iv_sell_put", "iv_sell_call")),
        ("put_call_ratio vs t_put_call_ratio", ("put_call_ratio", "t_put_call_ratio")),
        ("put_diff_quantity vs call_diff_quantity", ("put_diff_quantity", "call_diff_quantity")),
        ("PuttotalSellQuantity vs CalltotalSellQuantity", ("PuttotalSellQuantity", "CalltotalSellQuantity")),
        ("PutchangeinOpenInterest vs CallchangeinOpenInterest", ("PutchangeinOpenInterest", "CallchangeinOpenInterest")),
        ("put_quantity_change vs call_quantity_change", ("put_quantity_change", "call_quantity_change")),
        ("Change_put_call vs actual_change", ("Change_put_call", "actual_change")),
        ("put_quantity_change_avg_increase vs call_quantity_change_avg_increase", 
         ("put_quantity_change_avg_increase", "call_quantity_change_avg_increase"))
    ]
    
    # Create a multiselect to choose which metric pairs to analyze
    selected_metrics = st.sidebar.multiselect(
        "Select Metric Pairs to Analyze",
        options=[pair[0] for pair in metric_pairs],
        default=[pair[0] for pair in metric_pairs]  # Default to all metrics
    )
    
    # Filter the metric pairs based on selection
    selected_metric_pairs = [(name, cols) for name, cols in metric_pairs if name in selected_metrics]
    
    # Run analysis button
    if st.sidebar.button("Run Crossover Detection"):
        if not selected_metrics:
            st.warning("Please select at least one metric pair to analyze.")
        else:
            with st.spinner("Detecting crossovers for all selected metrics..."):
                # Run the analysis for all selected metric pairs
                result_df = run_async(process_all_strikes_all_metrics(df, target_strikes, selected_metric_pairs))
                
                # Display crossover results
                st.subheader("Crossover Results")
                if len(result_df) > 0:
                    # Show full data table
                    st.dataframe(result_df)
                    
                    # Add download button for results
                    csv = result_df.to_csv(index=False)
                    st.download_button(
                        label="Download Results as CSV",
                        data=csv,
                        file_name="crossover_results.csv",
                        mime="text/csv"
                    )
                    
                    # Visualize results
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.subheader("Crossovers by Strike Price")
                        strike_counts = result_df['target_strike'].value_counts().reset_index()
                        strike_counts.columns = ['Strike Price', 'Number of Crossovers']
                        st.bar_chart(strike_counts.set_index('Strike Price'))
                    
                    with col2:
                        st.subheader("Crossovers by Turnover Type")
                        turnover_counts = result_df['turnover_type'].value_counts().reset_index()
                        turnover_counts.columns = ['Turnover Type', 'Count']
                        st.bar_chart(turnover_counts.set_index('Turnover Type'))
                    
                    # Metric pair breakdown
                    st.subheader("Crossovers by Metric Pair")
                    metric_counts = result_df['metric_pair'].value_counts().reset_index()
                    metric_counts.columns = ['Metric Pair', 'Count']
                    st.bar_chart(metric_counts.set_index('Metric Pair'))
                    
                    # Summary statistics
                    st.subheader("Summary")
                    total_crossovers = len(result_df)
                    positive_crossovers = len(result_df[result_df['turnover_type'] == 'Positive Turnover'])
                    negative_crossovers = len(result_df[result_df['turnover_type'] == 'Negative Turnover'])
                    
                    metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
                    metrics_col1.metric("Total Crossovers", total_crossovers)
                    metrics_col2.metric("Positive Turnovers", positive_crossovers)
                    metrics_col3.metric("Negative Turnovers", negative_crossovers)
                    
                    # Show most recent crossovers
                    if len(result_df) > 0:
                        st.subheader("Most Recent Crossovers")
                        recent_df = result_df.head(10)
                        st.table(recent_df)
                else:
                    st.info("No crossovers detected for the selected parameters.")
    else:
        # Display a placeholder message when the app is first loaded
        st.info("👈 Set parameters in the sidebar and click 'Run Crossover Detection' to analyze the data.")

    # Option to show calculated columns
    if st.sidebar.checkbox("Show Calculated Columns"):
        st.subheader("Calculated Columns")
        
        # Show a sample of calculated columns
        calculated_columns = [
            'PuttotalBuyQuantity_diff', 'CalltotalBuyQuantity_diff', 
            'Callprice', 'Putprice', 'Change_put_call', 'actual_change',
            'call_quantity_change', 'put_quantity_change', 'put_diff_quantity', 
            'call_diff_quantity', 'act_CallunderlyingValue', 'act_PutunderlyingValue',
            'put_call_ratio', 't_put_call_ratio', 'iv_sell_put', 'iv_sell_call',
            'put_quantity_change_avg_increase', 'call_quantity_change_avg_increase', 
            'qty_avg_change_zero_line'
        ]
        
        # Filter to only include columns that actually exist
        existing_columns = [col for col in calculated_columns if col in df.columns]
        
        if existing_columns:
            sample_df = df[existing_columns].head(10)
            st.dataframe(sample_df)
        else:
            st.warning("No calculated columns found in the dataset.")
else:
    st.error(f"Failed to load data from {file_path}. Please check if the file exists and has the correct format.")