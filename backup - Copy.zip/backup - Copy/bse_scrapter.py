import requests
from bs4 import BeautifulSoup
import pandas as pd

# Function to scrape option chain data
def scrape_bse_option_chain():
    url = "https://www.bseindia.com/markets/Derivatives/DeriReports/DeriOptionchain.html"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
    }

    # Get the page content
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
        return None
    
    # Parse the content using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find the table that contains option chain data (Inspect the table's structure)
    table = soup.find('table', {'class': 'table'})
    
    if not table:
        print("Option chain table not found on the page.")
        return None
    
    # Extract the table headers
    headers = []
    for th in table.find_all('th'):
        headers.append(th.text.strip())
    
    # Extract the table rows
    rows = []
    for tr in table.find_all('tr'):
        cells = [td.text.strip() for td in tr.find_all('td')]
        if len(cells) > 0:
            rows.append(cells)
    
    # Convert the data to a pandas DataFrame
    df = pd.DataFrame(rows, columns=headers)
    
    return df

# Call the function and print the result
option_chain_df = scrape_bse_option_chain()

if option_chain_df is not None:
    print(option_chain_df)
