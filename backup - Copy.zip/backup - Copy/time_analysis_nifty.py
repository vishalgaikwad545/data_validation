import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import datetime
import os
from glob import glob
import time
import warnings
warnings.filterwarnings("ignore")

value_range = 20
# Set up page  layout
st.set_page_config(layout="wide")

# Function to load the Excel file (with caching)
@st.cache_data
def load_excel(file_path, retries=3, delay=5):
    for attempt in range(retries):
        try:
            # Try reading the Excel file
            return pd.read_excel(file_path, engine='openpyxl')
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                print(f"Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print("Max retries reached. Unable to load the file.")
                raise

# Function to get the list of available Excel files (with caching)
file_path = "C:\\Users\\vbgai\\Downloads\\"
# file_path = "C:\\Users\\vbgai\\OneDrive\\Desktop\\"
@st.cache_data
def get_file_list():
    # return glob("C:\\Users\\vbgai\\Downloads\\bank_option_*.xlsx")
    return glob(f"{{}}nifty_option_*.xlsx".format(file_path))
# Sidebar date input
selected_date = st.sidebar.date_input("Select Date", datetime.date.today())

start_time = st.sidebar.time_input("Start Time", datetime.time(9, 0))  # Default 9:00 AM
end_time = st.sidebar.time_input("End Time", datetime.time(16, 0))

# Reload button on the sidebar
if st.sidebar.button("Reload Excel"):
    # Clear the cache for both functions
    st.cache_data.clear()

# Construct the file path based on the selected date
file_pattern = f"{{}}nifty_option_{selected_date.day}_{selected_date.month}.xlsx".format(file_path)
file_list = get_file_list()

# Check if file exists, otherwise get the latest one
if not os.path.exists(file_pattern):
    file_list.sort(reverse=True, key=os.path.getmtime)
    if file_list:
        file_path = file_list[0]
    else:
        st.error("No Excel files found.")
        st.stop()
else:
    file_path = file_pattern

# Load Excel file
df = load_excel(file_path)
df_backup = df.copy()
unique_values = df_backup['PutstrikePrice'].nunique()
value_range = st.sidebar.number_input("Enter the number of values to display", value=60, step=10)

df_backup['Time'] = pd.to_datetime(df_backup['Time']).dt.strftime('%H:%M')
start_time_str = start_time.strftime('%H:%M')
end_time_str = end_time.strftime('%H:%M')
mask = (df_backup['Time'] >= start_time_str) & (df_backup['Time'] <= end_time_str)
df = df_backup[mask]
df = df_backup.tail(value_range * unique_values)
df['PuttotalBuyQuantity_diff'] = df.groupby(['Time', 'PutstrikePrice'])['PuttotalBuyQuantity'].diff()
df['CalltotalBuyQuantity_diff'] = df.groupby(['Time', 'CallstrikePrice'])['CalltotalBuyQuantity'].diff()
df['Callprice'] = df ['CallaskQty'] * df['CallaskPrice']
df ['Putprice'] = df ['PutaskQty'] * df['PutaskPrice']
df['Change_put_call'] = df['PutpchangeinOpenInterest'] - df['CallpchangeinOpenInterest']
df['actual_change'] = df['PutopenInterest'] - df['CallopenInterest']
df['call_quantity_change'] = df['CalltotalSellQuantity'] - df['CalltotalBuyQuantity'] 
df['put_quantity_change'] = df['PuttotalSellQuantity'] - df['PuttotalBuyQuantity']
df['put_call_ratio'] =  df['PutopenInterest'] / df['CallopenInterest']
df['t_put_call_ratio'] =  df['PutchangeinOpenInterest'] / df['CallchangeinOpenInterest']
window=3
df['put_quantity_change_avg_increase'] = df['put_quantity_change'].rolling(window=window).apply(lambda x: round((x.iloc[-1] - x.iloc[0]) / window))
df['call_quantity_change_avg_increase'] = df['call_quantity_change'].rolling(window=window).apply(lambda x: round((x.iloc[-1] - x.iloc[0]) / window))
df['qty_avg_change_zero_line'] = df['call_quantity_change_avg_increase'] - df['put_quantity_change_avg_increase']



# Sidebar input for CallstrikePrice
callstrike_input = st.sidebar.number_input("Enter Call Strike Price", value=23250, step=50)
# value_range = st.sidebar.number_input("Enter the number of values to display", value=20, step=10)
# df = df_backup.tail(value_range * unique_values)
# Filter data based on the CallstrikePrice input (filtered early to optimize performance)
filtered_df = df[df['CallstrikePrice'] == callstrike_input]

# Dictionary mapping combined options for both Call and Put
options = {
    'Quantity_change':['put_quantity_change','call_quantity_change'],
    'Change in Open Interest': ['PutchangeinOpenInterest', 'CallchangeinOpenInterest'],
    'Open Interest': ['PutopenInterest', 'CallopenInterest'],
    'Total Buy Quantity': ['CalltotalBuyQuantity', 'PuttotalBuyQuantity'],
    'Total Sell Quantity': ['PuttotalSellQuantity', 'CalltotalSellQuantity'],
    'Last Price': ['CalllastPrice', 'PutlastPrice'],
    'Ask Quantity': ['CallaskQty', 'PutaskQty'],
    'Put Call Ratio':['put_call_ratio','put_call_ratio'],
    'Net Buy Quantity': ['CalltotalBuyQuantity_diff','PuttotalBuyQuantity_diff'],
    'Today Put Call Ratio':['t_put_call_ratio','t_put_call_ratio'],
    'Percentage Change in Open Interest': ['CallpchangeinOpenInterest', 'PutpchangeinOpenInterest'],
    'Percent_change':['Change_put_call','Change_put_call'],
    'actual_change':['actual_change','actual_change'],
    'Total Traded Volume': ['CalltotalTradedVolume', 'PuttotalTradedVolume'],
    'Implied Volatility': ['CallimpliedVolatility', 'PutimpliedVolatility'],
    
    'Change': ['Callchange', 'Putchange'],
    'Percentage Change': ['CallpChange', 'PutpChange'],
    
    'Bid Quantity': ['CallbidQty', 'PutbidQty'],
    'Bid Price': ['Callbidprice', 'Putbidprice'],
    
    'Ask Price': ['CallaskPrice', 'PutaskPrice'],
    'Underlying Value': ['CallunderlyingValue', 'PutunderlyingValue'],
    "Underlying Total Value":["Callprice","Putprice"],
    'avg_quantity_change':['put_quantity_change_avg_increase','call_quantity_change_avg_increase'],
    'qty_avg_change_zero_line':['qty_avg_change_zero_line','qty_avg_change_zero_line']
}

# Sidebar multiselect for combined Call and Put options
selected_option = st.sidebar.selectbox("Select Option to Plot", list(options.keys()))

selected_sec_option = st.sidebar.selectbox("Select Second Option to Plot", list(options.keys()),index=1)
selected_thd_option = st.sidebar.selectbox("Select Third Option to Plot", list(options.keys()),index=4)
selected_4th_option = st.sidebar.selectbox("Select fourth Option to Plot", list(options.keys()),index=5)
# Get the corresponding Call and Put columns
selected_call_column, selected_put_column = options[selected_option]
selected_sec_call_column, selected_sec_put_column = options[selected_sec_option]
selected_thd_call_column, selected_thd_put_column = options[selected_thd_option]
selected_4th_call_column, selected_4th_put_column = options[selected_4th_option]

if filtered_df.empty:
    st.write("No data available for the selected CallstrikePrice.")
else:


    # Function to create a plotly figure for Call and Put columns
    def create_figure(filtered_df, x_column, y_call_column, y_put_column, option_title, strike_price):
        fig = go.Figure()

        # Add traces for selected Call and Put columns
        fig.add_trace(go.Scatter(
            x=filtered_df[x_column], y=filtered_df[y_call_column],
            mode='lines', name=f'{y_call_column}'[:10], line=dict(color='green')
            # mode='lines', line=dict(color='green')
        ))
        fig.add_trace(go.Scatter(
            x=filtered_df[x_column], y=filtered_df[y_put_column],
            mode='lines', name=f'{y_put_column}'[:10], line=dict(color='red')
            # mode='lines',  line=dict(color='red')
        ))

        # Update layout
        fig.update_layout(
            xaxis={
                'title': 'Time',
                'rangeslider': {'visible': True},
                'type': 'category',
                'tickangle': -45,
            },
            yaxis={
                'title': f'{option_title} for Call and Put',
                'fixedrange': False,
            },
            title=f'{option_title} for Strike Price {strike_price}',
            height=400,
        )

        # Set dynamic y-axis scaling
        fig.update_yaxes(autorange=True)

        return fig

    # Plot 1
    fig = create_figure(
        filtered_df, 'Time', selected_call_column, selected_put_column,
        selected_option, callstrike_input
    )
    st.plotly_chart(fig, use_container_width=True)

    # Plot 2
    fig1 = create_figure(
        filtered_df, 'Time', selected_sec_call_column, selected_sec_put_column,
        selected_sec_option, callstrike_input
    )
    st.plotly_chart(fig1, use_container_width=True)

    # Plot 3
    fig3 = create_figure(
        filtered_df, 'Time', selected_thd_call_column, selected_thd_put_column,
        selected_thd_option, callstrike_input
    )
    st.plotly_chart(fig3, use_container_width=True)
    
    fig4 = create_figure(
        filtered_df, 'Time', selected_4th_call_column, selected_4th_put_column,
        selected_4th_option, callstrike_input
    )
    st.plotly_chart(fig4, use_container_width=True)


        
    st.write(f"Loaded file: {os.path.basename(file_path)}")
